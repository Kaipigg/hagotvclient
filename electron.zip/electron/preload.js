import { contextBridge, ipcRenderer } from 'electron';
// 暴露给前端的 API
var electronAPI = {
    // 窗口控制
    minimize: function () { return ipcRenderer.send('window-minimize'); },
    maximize: function () { return ipcRenderer.send('window-maximize'); },
    close: function () { return ipcRenderer.send('window-close'); },
    isMaximized: function () { return ipcRenderer.invoke('window-is-maximized'); },
    onMaximizedChange: function (callback) {
        ipcRenderer.on('window-maximized', function (_, isMaximized) { return callback(isMaximized); });
    },
    // 文件对话框
    openFileDialog: function (options) {
        return ipcRenderer.invoke('dialog-open-file', options);
    },
    // 平台信息
    platform: process.platform,
};
contextBridge.exposeInMainWorld('electronAPI', electronAPI);
