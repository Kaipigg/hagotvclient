declare const electronAPI: {
    minimize: () => void;
    maximize: () => void;
    close: () => void;
    isMaximized: () => Promise<any>;
    onMaximizedChange: (callback: (isMaximized: boolean) => void) => void;
    openFileDialog: (options: Electron.OpenDialogOptions) => Promise<any>;
    platform: NodeJS.Platform;
};
declare global {
    interface Window {
        electronAPI: typeof electronAPI;
    }
}
export {};
